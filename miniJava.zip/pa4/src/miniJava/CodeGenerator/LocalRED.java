package miniJava.CodeGenerator;

public class LocalRED {
	int displacement;
	public LocalRED(int d){
		displacement = d;
	}
}
