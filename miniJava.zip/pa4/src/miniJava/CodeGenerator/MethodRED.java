package miniJava.CodeGenerator;

public class MethodRED {
	int displacement;
	public MethodRED(int d){
		displacement = d;
	}
}
