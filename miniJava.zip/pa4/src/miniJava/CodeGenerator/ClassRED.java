package miniJava.CodeGenerator;

public class ClassRED {
	public int size;
	public ClassRED(int size) {
		this.size = size;
	}
}
