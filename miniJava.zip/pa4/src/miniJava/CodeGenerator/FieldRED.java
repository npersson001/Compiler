package miniJava.CodeGenerator;

public class FieldRED {
	int displacement;
	public FieldRED(int d){
		displacement = d;
	}
}
